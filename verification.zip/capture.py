import html, json, pathlib, re
from playwright.sync_api import sync_playwright
root=pathlib.Path('/task/artifacts')
shas={'base':'03af220ac0023ab846727397b3a1de9efa0aec42','head':'2a2cac7499d45c7bea8d409a99880ad519f64430'}
sections=[]
for side,label in (('base','BEFORE'),('head','AFTER')):
    facts=json.loads((root/f'facts-{side}.json').read_text())
    lines=[line for line in (root/f'codex-{side}.txt').read_text().splitlines() if line.startswith('ERROR:')]
    output='\n'.join(lines)
    sections.append(f'<section id="{side}"><h2>{label} <small>{shas[side][:12]}</small></h2><p>Captured Codex CLI 0.154.0 output</p><pre>{html.escape(output)}</pre><footer>{facts["reconnects"]} reconnects · SSE error.code = {html.escape(json.dumps(facts["overflow_code"]))}</footer></section>')
page_html='''<!doctype html><meta charset="utf-8"><style>
*{box-sizing:border-box}body{margin:0;padding:26px;background:#0e1117;color:#e6edf3;font:16px Arial,sans-serif}h1{font-size:24px;margin:0 0 10px}header p{color:#a7b2c4;margin:0 0 22px}main{display:grid;grid-template-columns:1fr 1fr;gap:18px}section{background:#171d27;border:1px solid #3b4657;border-radius:10px;padding:22px;min-height:365px}h2{font-size:19px;margin:0 0 8px}small{color:#a7b2c4;font:14px monospace;margin-left:8px}section p{font-size:14px;color:#a7b2c4}pre{font:15px/1.65 monospace;white-space:pre-wrap;overflow-wrap:anywhere;min-height:202px}footer{font:14px monospace;border-top:1px solid #3b4657;padding-top:18px}#base h2{color:#ffbb86}#head h2{color:#8ce5b5}.note{font-size:13px;color:#a7b2c4;margin-top:16px}
</style><header><h1>PR #10938 · Context overflow in Codex</h1><p>Same 700-note prompt · Qwen3-0.6B Q4_K_M · 4,096-token context · NVIDIA RTX 5060 Ti</p></header><main>'''+''.join(sections)+'''</main><p class="note">Terminal transcript excerpts from real Codex runs against separate Studio instances. Full logs accompany these captures.</p>'''
(root/'codex-before-after.html').write_text(page_html)
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':520},device_scale_factor=1)
    page.set_content(page_html)
    assert page.locator('#base').inner_text().count('Reconnecting...')==5
    assert "Codex ran out of room" in page.locator('#head').inner_text()
    page.screenshot(path=str(root/'codex-before-after.png'),full_page=True)
    for side in ('base','head'):
        page.locator(f'#{side}').screenshot(path=str(root/f'codex-{side}.png'))
    (root/'capture-meta.json').write_text(json.dumps({'browser':browser.version,'viewport':{'width':1440,'height':520},'base_sha':shas['base'],'head_sha':shas['head'],'source':'captured terminal transcript excerpts','expected':'five reconnects and stream disconnected before; zero reconnects and context-window error after'},indent=2))
    browser.close()
