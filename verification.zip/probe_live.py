import json, pathlib, os, sys, subprocess, time, re
import httpx
root = pathlib.Path('/task')
side=sys.argv[1]
connection=json.loads((root/f'connection-{side}.json').read_text())
base=f"http://127.0.0.1:{connection['port']}"
client=httpx.Client(base_url=base,headers={'Authorization':f"Bearer {connection['key']}"},timeout=120,trust_env=False)
model='Qwen3-0.6B-Q4_K_M'
prompt='Summarize these notes in one sentence.\n'+'\n'.join(f'Note {i:04d}: the quick brown fox jumps over the lazy dog beside the quiet riverbank at dawn.' for i in range(700))
facts={'side':side,'model':model,'context':4096}
for stream in (False, True):
    response=client.post('/v1/responses',json={'model':model,'input':'Say hello briefly.','max_output_tokens':128,'stream':stream,'enable_thinking':False})
    (root/'artifacts'/f'{side}-success-{stream}.txt').write_text(response.text)
    assert response.status_code==200, response.text
    if stream:
        assert 'response.completed' in response.text and 'response.failed' not in response.text,response.text
    else:
        assert response.json()['status']=='completed', response.text
    facts[f'success_stream_{stream}']='passed'
response=client.post('/v1/responses',json={'model':model,'input':prompt,'stream':True,'max_output_tokens':64})
(root/'artifacts'/f'{side}-overflow.sse').write_text(response.text)
failed=[json.loads(line[6:]) for line in response.text.splitlines() if line.startswith('data: ') and '"response.failed"' in line]
assert len(failed)==1,response.text
facts['overflow_code']=failed[0]['response']['error']['code']
assert facts['overflow_code']==(400 if side=='base' else 'context_length_exceeded'),facts
home=root/f'codex-{side}'
home.mkdir(exist_ok=True)
(home/'config.toml').write_text(f'''model = "{model}"
model_provider = "studio"
model_context_window = 100000
[model_providers.studio]
name = "Studio"
base_url = "{base}/v1"
wire_api = "responses"
env_key = "STUDIO_API_KEY"
''')
env=dict(os.environ,CODEX_HOME=str(home),STUDIO_API_KEY=connection['key'])
start=time.monotonic()
result=subprocess.run(['/task/bin/codex','exec','--skip-git-repo-check','--sandbox','read-only',prompt],cwd='/task/tmp',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
output=result.stdout.replace(connection['key'],'<redacted>')
(root/'artifacts'/f'codex-{side}.txt').write_text(output)
facts.update(codex_exit=result.returncode,codex_seconds=round(time.monotonic()-start,2),reconnects=len(re.findall(r'Reconnecting\.\.\.',output)),context_message="Codex ran out of room in the model's context window" in output,disconnected='stream disconnected before completion' in output)
(root/'artifacts'/f'facts-{side}.json').write_text(json.dumps(facts,indent=2))
print(json.dumps(facts,indent=2),flush=True)
assert facts['reconnects']==(5 if side=='base' else 0),facts
assert facts['context_message']==(side!='base'),facts
