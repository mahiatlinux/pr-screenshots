import os
import pathlib
import subprocess
import sys
root = pathlib.Path(__file__).resolve().parent
args = ['bwrap', '--die-with-parent', '--unshare-user', '--unshare-pid', '--unshare-ipc', '--unshare-uts', '--clearenv']
for path in ['/usr', '/lib', '/lib64', '/bin', '/sbin']:
    if os.path.exists(path):
        args += ['--ro-bind', path, path]
for path in ['/etc/ssl', '/etc/resolv.conf', '/etc/hosts', '/etc/nsswitch.conf', '/etc/ld.so.cache', '/etc/fonts']:
    if os.path.exists(path):
        args += ['--ro-bind', path, path]
args += ['--proc', '/proc', '--dev', '/dev', '--bind', str(root), str(root), '--bind', str(root/'scratch'), '/tmp']
env = {'PATH':f'{root}/toolbin:/usr/bin:/bin','HOME':str(root/'empty-home'),'TMPDIR':str(root/'scratch'),'UV_CACHE_DIR':str(root/'cache/uv'),'UV_PYTHON_INSTALL_DIR':str(root/'downloads/python'),'XDG_CACHE_HOME':str(root/'cache/xdg'),'HF_HOME':str(root/'cache/hf'),'HF_HUB_CACHE':str(root/'cache/hf/hub'),'HF_XET_CACHE':str(root/'cache/hf/xet'),'npm_config_cache':str(root/'cache/npm'),'PLAYWRIGHT_BROWSERS_PATH':str(root/'downloads/browsers'),'UNSLOTH_STUDIO_HOME':str(root/'scratch/studio'),'LANG':'C.UTF-8','UNSLOTH_ALLOW_CPU':'1','UNSLOTH_IS_PRESENT':'1','UNSLOTH_STUDIO_DISABLE_DEVICE_PROBE':'1'}
for k,v in env.items():
    args += ['--setenv',k,v]
args += ['--chdir',str(root), *sys.argv[1:]]
raise SystemExit(subprocess.call(args))
