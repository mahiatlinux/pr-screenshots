import os,pathlib,subprocess,time,json
from Xlib import display,X
from PIL import Image
root=pathlib.Path('/task')
env=dict(os.environ,DISPLAY=':198',LD_LIBRARY_PATH='/task/terminal/usr/lib/x86_64-linux-gnu',TERM='xterm-256color',SHELL='/bin/bash',LIBGL_ALWAYS_SOFTWARE='1',__EGL_VENDOR_LIBRARY_FILENAMES='/usr/share/glvnd/egl_vendor.d/50_mesa.json')
pathlib.Path('/tmp/.X11-unix').mkdir(exist_ok=True)
xvfb=subprocess.Popen(['Xvfb',':198','-screen','0','1600x1100x24','-ac','-nolisten','tcp','-extension','GLX'],env=env,stdout=subprocess.DEVNULL,stderr=open(root/'artifacts/xvfb.log','w'))
try:
    for _ in range(100):
        try:
            d=display.Display(':198'); break
        except Exception: time.sleep(.1)
    for side in ('base','head'):
        title=f'PR 10938 - {side} - Codex CLI 0.154.0'
        xterm=subprocess.Popen(['/task/terminal/usr/bin/xterm','-hold','-geometry','125x29+0+0','-fa','DejaVu Sans Mono','-fs','13','-bg','#10141a','-fg','#e6edf3','-b','16','-title',title,'-e','/usr/bin/script','-q','-e','-c',f'/task/runtime/bin/python /task/terminal_run.py {side}',f'/task/artifacts/terminal-{side}.typescript'],env=env,stdout=subprocess.DEVNULL,stderr=open(root/f'artifacts/xterm-{side}.log','w'))
        try:
            for _ in range(1800):
                if (root/f'done-{side}.json').exists(): break
                if xterm.poll() is not None: raise RuntimeError(f'xterm {side} exited {xterm.returncode}')
                time.sleep(.1)
            else: raise TimeoutError(side)
            time.sleep(1)
            windows=d.screen().root.query_tree().children
            window=next(w for w in windows if w.get_wm_name()==title)
            geometry=window.get_geometry()
            raw=window.get_image(0,0,geometry.width,geometry.height,X.ZPixmap,0xffffffff)
            shot=Image.frombytes('RGB',(geometry.width,geometry.height),raw.data,'raw','BGRX')
            shot.save(root/f'artifacts/terminal-{side}.png')
            print(side,geometry.width,geometry.height,flush=True)
        finally:
            xterm.terminate(); xterm.wait(timeout=10)
    d.close()
finally:
    xvfb.terminate(); xvfb.wait(timeout=10)
