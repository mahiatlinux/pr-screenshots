import os, sys, pathlib
root = pathlib.Path(__file__).resolve().parent
for name in ('home','tmp','cache','bin','python'):
    (root/name).mkdir(exist_ok=True)
args = ['bwrap','--unshare-all','--share-net','--die-with-parent','--new-session','--clearenv']
for path in ('/usr','/lib','/lib64','/bin','/sbin'):
    args += ['--ro-bind',path,path]
for path in ('/etc/fonts','/etc/ssl','/etc/resolv.conf','/etc/hosts','/etc/nsswitch.conf','/etc/ld.so.cache'):
    args += ['--ro-bind',path,path]
args += ['--proc','/proc','--dev','/dev','--ro-bind','/sys','/sys','--bind',str(root),'/task','--bind',str(root/'tmp'),'/tmp']
for device in pathlib.Path('/dev').glob('nvidia*'):
    args += ['--dev-bind',str(device),str(device)]
for key,value in {'HOME':'/task/home','PATH':'/task/bin:/usr/bin:/bin','TMPDIR':'/tmp','XDG_CACHE_HOME':'/task/cache','UV_CACHE_DIR':'/task/cache/uv','UV_PYTHON_INSTALL_DIR':'/task/python','HF_HOME':'/task/cache/hf','HF_HUB_CACHE':'/task/cache/hf/hub','HF_XET_CACHE':'/task/cache/hf/xet','PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8'}.items():
    args += ['--setenv',key,value]
os.execvp('bwrap',args+['--chdir','/task']+sys.argv[1:])
