import json, pathlib, httpx
root=pathlib.Path('/task')
facts={}
for side in ('base','head'):
    c=json.loads((root/f'connection-{side}.json').read_text())
    with httpx.Client(base_url=f"http://127.0.0.1:{c['port']}",headers={'Authorization':f"Bearer {c['key']}"},timeout=120,trust_env=False) as client:
        payload={'model':'Qwen3-0.6B-Q4_K_M','input':'Call lookup for Paris.','stream':True,'max_output_tokens':512,'tools':[{'type':'function','name':'lookup','description':'Look up a city.','parameters':{'type':'object','properties':{'city':{'type':'string'}},'required':['city'],'additionalProperties':False}}],'tool_choice':{'type':'function','name':'lookup'}}
        response=client.post('/v1/responses',json=payload)
        (root/'artifacts'/f'{side}-tool.sse').write_text(response.text)
        assert response.status_code==200,response.text
        events=[json.loads(line[6:]) for line in response.text.splitlines() if line.startswith('data: ')]
        completed=[e for e in events if e.get('type')=='response.completed']
        assert len(completed)==1,response.text
        calls=[item for item in completed[0]['response']['output'] if item['type']=='function_call']
        assert len(calls)==1 and calls[0]['name']=='lookup',calls
        assert json.loads(calls[0]['arguments'])=={'city':'Paris'},calls
        payload.update(input=[{'role':'user','content':'Call lookup for Paris.'},calls[0],{'type':'function_call_output','call_id':calls[0]['call_id'],'output':'Paris is the capital of France.'}], tool_choice='none')
        response=client.post('/v1/responses',json=payload)
        (root/'artifacts'/f'{side}-tool-followup.sse').write_text(response.text)
        assert response.status_code==200 and 'response.completed' in response.text and 'response.failed' not in response.text,response.text
        facts[side]={'function':'lookup','arguments':{'city':'Paris'},'tool_result_followup':'completed'}
(root/'artifacts'/'tools-facts.json').write_text(json.dumps(facts,indent=2))
print(json.dumps(facts,indent=2))
