"""Which scene photographs which PR, and what the shot is supposed to prove.

`expect` is the point of this file. A scene that runs cleanly and produces two
identical images is the default failure mode of this whole exercise -- a missed
click, the wrong dropdown, or a Studio that never rebuilt all look like "the PR
changed nothing". Writing down the expected difference BEFORE running turns that
silent failure into a checkable claim.

`needs_model` marks scenes that must load real weights. Those are slow and need a
GPU; the cheap ones (Hub listings only) should be developed first.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ScenePlan:
    pr: int
    scene: str
    what: str                       # the UI surface photographed
    expect: str                     # the difference that MUST be visible
    kwargs: dict = field(default_factory=dict)
    needs_model: bool = False
    verified: Optional[str] = None  # what was actually observed, once run


REGISTRY: dict[int, ScenePlan] = {
    9909: ScenePlan(
        pr=9909,
        scene="parallel_tool_call_cards",
        what="Chat thread after two rounds of four id-less Python calls that all reuse delta index 0",
        expect="BEFORE shows one malformed merged call and its failed result per round. "
               "AFTER shows four separate completed cards per round, survives reload, and replays eight "
               "unique tool-call ids with valid JSON arguments. Facts: first_round_cards 2 -> 4, "
               "reloaded_cards 2 -> 4, total_cards 4 -> 8, and replay_valid false -> true.",
        verified="confirmed by eye at repaired head 47f028aca vs merge base a11d9537b. "
                 "The baseline merges all four Python payloads into one malformed call per round; "
                 "the repaired head shows alpha, beta, gamma, and delta as separate completed calls.",
    ),
    8768: ScenePlan(
        pr=8768,
        scene="model_auto_switch_description",
        what="Settings -> API Keys -> Model auto-switch (OpenAI API)",
        expect="BEFORE describes loading a downloaded GGUF named in an API request. "
               "AFTER describes loading a downloaded model. Facts: mentions_gguf "
               "true -> false and mentions_model false -> true.",
        verified="confirmed by eye at repaired head 9e3689488 vs merge base 0a472c7c7. "
                 "The first row changes only from 'Load a downloaded GGUF named in an "
                 "API request before serving. Off by default.' to 'Load a downloaded "
                 "model named in an API request before serving. Off by default.' Facts "
                 "agree: mentions_gguf true -> false and mentions_model false -> true.",
    ),
    9896: ScenePlan(
        pr=9896,
        scene="api_monitor_streamed_tool_calls",
        what="API Monitor request detail after an OpenAI-compatible provider streams one tool call across eleven argument fragments",
        expect="BEFORE shows eleven fragmented Tool call entries, including fallback names such as "
               "tool. AFTER shows one complete Tool call: terminal({\"command\":\"echo "
               "HERMES_UNSLOTH_OK\"}). Facts: tool_call_label_count 11 -> 1 and "
               "fragmented_fallback_visible true -> false.",
        verified="confirmed by eye at repaired head 8d84b4b1a vs merge base d89c43d40. "
                 "The API Monitor Reply block changes from eleven adjacent Tool call "
                 "entries, ten named tool, to one complete terminal call. Structured "
                 "facts agree: tool_call_label_count 11 -> 1 and "
                 "fragmented_fallback_visible true -> false. Both sides received a "
                 "terminal [DONE] marker and completed with stop_reason=tool_calls.",
    ),
    9770: ScenePlan(
        pr=9770,
        scene="ollama_reasoning_models",
        what="Settings -> Connections -> Ollama edit form",
        expect="BEFORE has no Reasoning model control for Ollama. AFTER shows the "
               "This server has reasoning models toggle and, when enabled, separate "
               "deepseek-r1:8b and llama3.2:3b checkboxes. Facts: reasoning_toggle_visible "
               "false -> true and per_model_labels [] -> both model ids.",
    ),
    9716: ScenePlan(
        pr=9716,
        scene="web_search_alias_recovery",
        what="Chat thread after a custom local provider emits web_search with an href alias",
        expect="BEFORE shows Used tool: Web Search and the final reply says "
               "'Alias fetch failed: web_search returned No query provided.' AFTER shows "
               "Used tool: Read example.com and the final reply says 'Alias fetch succeeded: "
               "web_search fetched Example Domain.' Facts: tool_result_kind "
               "empty_query_error -> fetched_page, has_no_query true -> false, and "
               "has_example_domain false -> true.",
        verified="confirmed by eye at original head 45ad374a8 vs merge base 4deb8ad2d. "
                 "The tool card changes from Used tool: Web Search to Used tool: Read "
                 "example.com, and the final answer changes from the exact No query provided "
                 "failure to the Example Domain fetch success. Two provider turns ran on "
                 "both sides and the structured facts match.",
    ),
    9320: ScenePlan(
        pr=9320,
        scene="api_profile_stats",
        what="Settings -> Profile with one API-only usage receipt and no Studio chats",
        expect="The overview changes from 'No chats yet.' to 1.5K lifetime tokens, one "
               "active day, and api-model. The detail frame shows Studio Chat tokens 0 "
               "and API tokens 1.5K. Facts: schema_has_api_usage false -> true, "
               "total_tokens 0 -> 1500, api_tokens 0 -> 1500, messages remains 0.",
    ),
    9319: ScenePlan(
        pr=9319,
        scene="voice_custom_stt",
        what="Settings -> Voice -> Dictation engine menu",
        expect="BEFORE shows Browser and Local transcription. AFTER adds Custom endpoint. "
               "Facts: option_count 2 -> 3 and custom_visible false -> true.",
        verified="confirmed by eye at head 0a5c97be8 vs merge base 489fab4a7. The "
                 "Dictation engine menu changes from Browser and Local transcription to "
                 "Browser, Local transcription and Custom endpoint. Facts agree: "
                 "option_count 2 -> 3 and custom_visible false -> true. TTS controls are "
                 "unchanged in the same frame.",
    ),
    8222: ScenePlan(
        pr=8222, scene="gguf_picker_rows",
        what="Model Hub quant list for a multi-checkpoint GGUF repo",
        expect="22 rows -> 63 rows; BF16 126 GB -> three 42 GB rows "
               "(BF16, BF16 · distilled, BF16 · distilled-1.1)",
        kwargs={"repo": "unsloth/LTX-2.3-GGUF"},
        verified="confirmed at head 69f54b51 on a clean two-install run: 22 -> 63 rows, "
                 "BF16 126 GB -> three 42 GB rows, Q8_0 68 GB -> 23 GB, and the bare "
                 "BF16 (dev) row selectable for the first time. API agrees: 117.45 GiB "
                 "-> 39.15 GiB. Side effect worth knowing: the DEFAULT selection also "
                 "changes (BF16 -> Q4_K_M · distilled-1.1), since the default resolver "
                 "now picks among real checkpoints. IDEMPOTENCE measured on full row "
                 "identity (key+label+size+filename, not row counts): flat, sharded and "
                 "quant-named-subdirectory repos are byte-for-byte unchanged; the mildly "
                 "affected ones keep their keys and only correct the size. The one "
                 "migration effect is that LTX-2.3-GGUF's surviving bare keys repoint "
                 "from distilled-1.1 to the dev checkpoint",
    ),
    8255: ScenePlan(
        pr=8255, scene="gguf_picker_rows",
        what="Model Hub quant list for a repo publishing one quant at several bit widths",
        expect="4 rows -> 18 rows, each at its own true size",
        kwargs={"repo": "byteshape/Llama-3.1-8B-Instruct-GGUF",
                # Fixed clip on the detail pane: the rows are 12 px type, and a
                # full 1500 px viewport renders at ~440 px per half in a comment.
                "clip": {"x": 780, "y": 150, "width": 700, "height": 620}},
        verified="confirmed by eye at head 4b470d414 vs merge base 871a088b5 (the base is "
                 "8222's branch `ggufrows`, NOT main -- this PR is stacked, so BEFORE "
                 "already contains 8222's family narrowing and the pair isolates the bpw "
                 "key alone). Picker: 4 rows -> 18 rows. BEFORE rows and the sizes the "
                 "picker advertised: Q4_K_S 16 GB, IQ4_XS 12 GB, Q3_K_S 16 GB, IQ3_S 18 GB "
                 "-- those are the SUMS of the 4/3/5/6 files sharing each token (Hub "
                 "listing: 16.0/11.6/16.1/17.7 GB), while the row itself resolved to one "
                 "file, Q4_K_S -> ...-Q4_K_S-3.60bpw.gguf at 3.63 GB. So BEFORE advertises "
                 "16 GB for a 3.6 GB download and the other 14 checkpoints are "
                 "unreachable. AFTER every file is its own row at its own size, 4.33 GB "
                 "down to 2.56 GB, and /api/models/gguf-variants agrees exactly with the "
                 "Hub listing on all 18. NOTE the summed size is computed in the FRONTEND: "
                 "the BEFORE backend endpoint already returns the single-file size "
                 "(3.63 GB) while the picker draws 16 GB, so the two disagree until this "
                 "PR keys them the same way. "
                 "GOTCHAS this run hit, both of which produced BYTE-IDENTICAL halves on "
                 "the first attempt (md5 equal, and the shot was of "
                 "YorkieOH10/Meta-Llama-3.1-8B-Instruct-Q8_0-GGUF). (1) a search RESULT ROW "
                 "is also a <button>, and on this query most results are named after a "
                 "quant (`...-Q8_0-GGUF`), so open_list's bare quant-token match hit the "
                 "results list and SELECTED an unrelated repo; the scene now filters the "
                 "selector with has_not_text on row chrome (relative date, download count). "
                 "(2) assert_showing passed on the wrong page: the results column is headed "
                 "'Results for \"byteshape/Llama-3.1-8B-Instruct-GGUF\"', which contains the "
                 "leaf, so the assertion was satisfied by the query typed rather than by "
                 "anything selected; the scene now asserts an EXACT heading plus the owner "
                 "line. Also: unsloth and byteshape both publish a repo named "
                 "Llama-3.1-8B-Instruct-GGUF and the owner-scoped results land before the "
                 "global ones, so `get_by_text(leaf).first` picked whichever had loaded -- "
                 "rows are now matched by owner, and Playwright's has_text normalises "
                 "whitespace so a `^owner$` row filter never matches",
    ),
    # MERGED 2026-08-09. Shot afterwards, at the merge base vs the merged head.
    8241: ScenePlan(
        pr=8241, scene="diffusion_quant_badge",
        what="loaded-models row for a GGUF pick the dense fast path replaced with a "
             "torchao int8 build",
        # Rewritten after reading the NET diff. The original expect ("BF16 -> Q8_0") was
        # taken from the PR title and from `gh pr diff --patch`, which replays the whole
        # commit series: an early commit added a `gguf_quant` field that a later one
        # dropped for the `gguf_variant` already on main. A plain GGUF load therefore
        # reads "GGUF · Q4_K_M" on BOTH sides and proves nothing.
        expect="loading unsloth/Z-Image-Turbo-GGUF Q4_K_M with transformer_quant=int8: "
               "'Image · z-image · GGUF · Q4_K_M · cuda' -> 'Image · z-image · INT8 · cuda'. "
               "The GGUF token goes because the pipeline never opened that file, and the "
               "precision becomes the dense build that actually ran. Same weights, same "
               "load, ONLY the label",
        kwargs={"repo": "unsloth/Z-Image-Turbo-GGUF",
                "filename": "z-image-turbo-Q4_K_M.gguf",
                "transformer_quant": "int8"},
        needs_model=True,
        verified="confirmed by eye at merged head 3c400936f vs merge base 8e558606a. Both "
                 "sides load identically (model_kind=gguf, gguf_variant=Q4_K_M, "
                 "transformer_quant=int8, dtype=bfloat16, device=cuda); the row reads "
                 "'Image · z-image · GGUF · Q4_K_M · c...' BEFORE (truncated by the 268 px "
                 "panel, which is itself the point: the width went on a filename nothing "
                 "opened) and 'Image · z-image · INT8 · cuda' AFTER. "
                 "GOTCHAS: (1) `gh pr diff --patch` replays the COMMIT SERIES, not the net "
                 "diff -- it showed a `gguf_quant` field this PR does not ship. Use "
                 "`git diff <base> <head>`. (2) /images/load returns in ~2 s with "
                 "loaded=false and finishes later, so status must be polled. (3) the whole "
                 "load, weights cached, takes about 10 s on this box",
    ),
    8219: ScenePlan(
        pr=8219, scene="image_generation_stop",
        what="Images composer action row during a generation, and again just after Stop",
        expect="two pairs on a 50-step batch-of-4 Z-Image run. (0) mid-run: BEFORE offers no "
               "way to stop it, AFTER shows Stop in place of Generate. (1) eight seconds "
               "later: AFTER is back to Generate with generate-progress active=false, BEFORE "
               "is still running. API: POST /images/generate/cancel 404 on the base, 200 on "
               "the head",
        kwargs={"repo": "unsloth/Z-Image-Turbo-GGUF",
                "filename": "z-image-turbo-Q4_K_M.gguf"},
        needs_model=True,
        verified="confirmed by eye at head 58c8c4642 vs merge base 8e558606a. pair_00 mid-run: "
                 "BEFORE a disabled spinner reading Generate, AFTER a live Stop. pair_01: "
                 "BEFORE still a disabled spinner (active=true at step 19 after 60 s), AFTER "
                 "back to a live green Generate with active=false. cancel route 405 -> 200. "
                 "GOTCHAS, three, and the middle one nearly shipped a wrong claim. "
                 "(1) get_by_role('button', name='Stop', exact=True) matches NOTHING here even "
                 "though inner_text is exactly 'Stop' -- the icon contributes to the accessible "
                 "name. Filter on text. That failure was silent: the click was skipped and the "
                 "pair simply showed two running sides. (2) cancellation latency is batch "
                 "dependent, measured: ~20 s at batch 4, under 4 s at batch 1. The original "
                 "fixed 8 s wait photographed AFTER still on Stop, which reads as 'the button "
                 "does nothing'. Poll to inactive instead. (3) BEFORE's Steps slider maxes at "
                 "100 and AFTER's at 50, so the two runs are not the same length; it does not "
                 "affect this claim but do not read it as a difference this PR made",
    ),
    8223: ScenePlan(
        pr=8223, scene="companion_assets_panel",
        what="Hub On Device tab: toolbar, and the delete dialog for an image GGUF and for "
             "the companion base repo its quants share (issue 8116)",
        expect="three differences on one cache holding unsloth/FLUX.2-klein-4B-GGUF "
               "(Q2_K + Q4_K_M, 4.4 GB) and the companion base "
               "black-forest-labs/FLUX.2-klein-4B (8.2 GB of text encoders, VAE, "
               "tokenizer). (0) toolbar: no way to reclaim shared assets -> a 'Free up "
               "space' control. (1) deleting the GGUF repo: 'You can re-download it later.' "
               "and nothing else -> plus 'Frees 4.4 GB of disk space.' and 'This also "
               "leaves 8.2 GB of shared assets (black-forest-labs/FLUX.2-klein-4B) that "
               "nothing else needs. Remove them with Free up space on the On Device tab.' "
               "(2) deleting the shared base while a quant is installed: the same plain "
               "dialog with Delete ENABLED (it succeeds, stranding both quants) -> a red "
               "'These are shared assets that unsloth/FLUX.2-klein-4B-GGUF still needs, so "
               "they cannot be removed yet. Delete those models first.' with Delete "
               "DISABLED. API: /api/hub/delete-impact and /api/hub/orphan-companions 404 "
               "on the base and answer on the head",
        kwargs={"gguf_repo": "unsloth/FLUX.2-klein-4B-GGUF",
                "base_repo": "black-forest-labs/FLUX.2-klein-4B"},
        verified="confirmed by eye at head aacfb9c0f vs merge base f0ef75ec9, two installs, "
                 "one seeded cache (scripts/seed_8223_cache.py: 4,432,118,912 B of Q2_K + "
                 "Q4_K_M and 8,229,021,460 B of companion base, real blobs). pair_00 "
                 "toolbar: 'Free up space' appears between Add folder and All formats. "
                 "pair_01 GGUF delete: BEFORE ends at 'You can re-download it later.'; AFTER "
                 "adds 'Frees 4.4 GB of disk space.' and the 8.2 GB orphan sentence. pair_02 "
                 "base delete: BEFORE identical wording with Delete ENABLED; AFTER shows the "
                 "red refusal naming unsloth/FLUX.2-klein-4B-GGUF with Delete greyed out. "
                 "API: delete-impact 405 / orphan-companions 404 on the base; on the head "
                 "reclaimed_bytes 4,432,118,912 with the base as freeable at 8,229,021,460, "
                 "and blocked_by=['unsloth/FLUX.2-klein-4B-GGUF'] for the base. "
                 "GOTCHA for later PRs: this box sets XDG_CACHE_HOME to a SHARED HF cache of "
                 "~26 repos which Studio scans alongside HF_HOME, so an unisolated run "
                 "photographs other sessions' downloads and its byte counts move under it. "
                 "Pass all four of HF_HOME/HF_HUB_CACHE/HF_XET_CACHE/XDG_CACHE_HOME through "
                 "--studio-env",
    ),
    8224: ScenePlan(
        pr=8224, scene="image_memory_plan",
        what="Images page after asking for 2048x2048 on a device that cannot hold the "
             "activations (GPU 2 held down to about 14 GiB free by scripts/gpu_ballast.py)",
        expect="BEFORE the generation is started and dies in the allocator, so the page shows "
               "a bare failure. AFTER it is refused before any work with the arithmetic: "
               "'Generating at 2048x2048 needs about 29.20 GB of working memory (including "
               "about 2.00 GB of fixed overhead), but only about 0.00 GB is usable on this "
               "device (of the 13.59 GB currently free...)'. 1024x1024 succeeds on both sides, "
               "which is the control: the claim is that the refusal replaces a crash, not that "
               "big requests are blocked",
        kwargs={"repo": "unsloth/Z-Image-Turbo-GGUF",
                "filename": "z-image-turbo-Q4_K_M.gguf",
                "width": 2048, "height": 2048},
        needs_model=True,
        verified="RAN, and it did NOT show what `expect` predicted -- it showed the opposite, "
                 "which is the point of writing `expect` first. At head 67cbde473 vs merge base "
                 "f0ef75ec9, both sides offload_policy=model, free 15.2 GiB (BEFORE) vs 13.9 GiB "
                 "(AFTER): BEFORE GENERATED the 2048x2048 image, AFTER refused it claiming "
                 "29.20 GB of working memory against '0.00 GB usable of the 13.87 GB currently "
                 "free'. Measured the truth on the base build by sampling nvidia-smi every "
                 "0.4 s: free 17,304 MiB before the call, 8,564 MiB at the trough, so peak "
                 "working memory about 8.7 GB, and it returned a 2048x2048 image. The estimate "
                 "is ~3x high and refuses work that succeeds. Reported on the PR. "
                 "GOTCHA that nearly invalidated the first run: this box SHARES GPUs, and "
                 "another session released ~17 GiB between the two sides, so they measured "
                 "different devices. gpu_ballast.py now tops up while holding (never gives "
                 "back), and the scene records free_mib per side. Without both, 'one refused, "
                 "one succeeded' says nothing about the PR",
    ),
    8213: ScenePlan(
        pr=8213, scene="unified_memory_refusal",
        what="load refusal on a host that cannot fit the model in unified memory",
        expect="load proceeds and is OS-killed -> a refusal naming the shortfall",
    ),
    8232: ScenePlan(
        pr=8232, scene="gguf_download_plan",
        what="download manager panel while staging a GGUF pick, on the companion base item",
        expect="picking unsloth/Qwen-Image-2512-GGUF Q4_K_M stages the base repo at 58 GB "
               "-> about 17 GB, because the 11 dense transformer/ shards the GGUF replaces "
               "are no longer fetched. API plan total 66.08 GiB -> 28.02 GiB, transformer "
               "file count 11 -> 0. NOTE: the 'GGUF · BF16' label is 8241's bug, NOT this "
               "PR's; do not read a label change here as evidence for 8232",
        kwargs={"repo": "unsloth/Qwen-Image-2512-GGUF",
                "base_repo": "unsloth/Qwen-Image-2512",
                "filename": "qwen-image-2512-Q4_K_M.gguf",
                "quant": "Q4_K_M",
                # Both sides share one cache (--studio-env is not per side), so the scene
                # purges these two repos from it before each run. Without that the AFTER
                # total would be smaller because BEFORE already downloaded, not because of
                # the fix.
                "cache_hub": "outputs/ui_diff_8232/hf_cache/hub"},
        verified="confirmed by eye at head 02b77383e vs merge base f0ef75ec9, two installs, one "
                 "purged-per-side cache. pair_00 (the download panel, element shot): both halves "
                 "show unsloth/Qwen-Image-2512-GGUF as Downloaded, then the base item "
                 "unsloth/Qwen-Image-2512 at '4.3 KB / 58 GB' BEFORE and '357 MB / 17 GB' AFTER. "
                 "API plan: total 66.08 -> 28.02 GiB; the GGUF entry is 12.34 GiB on both sides "
                 "(unchanged, as it must be), and the base entry goes 53.74 GiB / 28 files / 11 "
                 "transformer shards -> 15.69 GiB / 17 files / 0. "
                 "GOTCHA: the panel shows ONE item at a time, so the shot has to wait for the "
                 "SECOND item; base_repo is a strict prefix of repo, so the match needs the "
                 "trailing separator or it fires on the GGUF row, which is identical on both "
                 "sides. Cost per side: the 13 GB GGUF downloads first (~20 s at 750 MB/s), then "
                 "the scene cancels the base transfer a few seconds in",
    ),
    # MERGED 2026-08-09. Shot afterwards, at the merge base vs the merged head.
    8196: ScenePlan(
        pr=8196, scene="video_family_train_picker",
        what="Images -> Train tab, the 'Model family' Select and the panel under it",
        # Written from the NET diff (git diff <merge-base> <head>), not from the PR body:
        # the body's "Deliberately left out / The Train UI listing" describes an EARLIER
        # commit. The merged head rewrites family_train_infos() to walk
        # _all_trainable_family_names() -- the image registry's trainable families UNION
        # TRAINABLE_VIDEO_FAMILIES -- so the listing does gain the video family.
        expect="the Model family dropdown gains one row, 'LTX-2', appended after the "
               "image families (mergeFamilies puts a backend family the frontend has no "
               "preset for last). Picking it, which is impossible on the BEFORE side, "
               "sets Base model to Lightricks/LTX-2 and shows the chips '19B' and "
               "'QLoRA 36GB+ VRAM' with the note 'Video: trains a style LoRA on still "
               "images.'. API /api/train/diffusion/info: families gains an ltx-2 entry "
               "with defaults rank 32 / lr 1e-4 / resolution 512 and deploy_base null. "
               "CAVEAT to check in the facts, not to assume: the head also drops any "
               "family whose pipeline class the installed diffusers lacks, so LTX-2 only "
               "appears where diffusers has LTX2Pipeline (0.39+)",
        verified="confirmed by eye at merged head 18dc63502 vs merge base f9656fd6c, two "
                 "installs, diffusers 0.39.0 with LTX2Pipeline present on BOTH sides (so the "
                 "availability filter is not what makes the difference). Model family menu: 7 "
                 "options -> 8, BEFORE flux.1 / flux.2-klein / flux.2-dev / qwen-image / "
                 "z-image / krea-2 / sdxl, AFTER the same seven plus ltx-2 appended last. "
                 "Picking it: Base model Lightricks/LTX-2, chips '19B' + 'QLoRA 36GB+ VRAM', "
                 "note 'Video: trains a style LoRA on still images.', defaults rank 32 / "
                 "lr 1e-4 / 512px / 20 warmup, deploy_base null (a video run publishes no "
                 "image LoRA catalog entry, so there is nothing to deploy). "
                 "CORRECTS AN EARLIER READ in this session that the feature was unreachable "
                 "from the Train tab. That came from the PR BODY, whose 'Deliberately left "
                 "out / The Train UI listing' paragraph describes an earlier commit; the net "
                 "diff at the merged head rewrites family_train_infos() to walk "
                 "_all_trainable_family_names() and the row is there. Read the net diff, not "
                 "the description, even on a merged PR",
    ),
    8244: ScenePlan(
        pr=8244, scene="video_family_train_picker",
        what="Images -> Train tab, the 'Model family' Select and the panel under it",
        # Written from the NET diff (git diff 749437314 70bdc2ceb), not the PR body. The
        # reachable-by-hand surface of this PR is one listing: TRAINABLE_VIDEO_FAMILIES
        # goes {ltx-2} -> {ltx-2, minimax-h3}, which is what _all_trainable_family_names()
        # feeds family_train_infos() and therefore GET /api/train/diffusion/info, which is
        # what the Select is built from. Everything else the PR ships (the H3 trainer, the
        # clip dataset layer, the packed-sequence layout, the H3 inference paths) is behind
        # that row.
        expect="the Model family dropdown gains exactly one row, 'MiniMax-H3': 8 options "
               "-> 9. mergeFamilies appends any backend family the frontend has no preset "
               "for, in backend order, and the video registry lists minimax-h3 before "
               "ltx-2, so the new row lands next to LTX-2 among the appended ones. Picking "
               "it, which is impossible on the BEFORE side, sets Base model to "
               "MiniMaxAI/MiniMax-H3 and shows the chips '31B' and 'QLoRA 72GB+ VRAM' with "
               "the note 'Video with sound: trains on clips that have a soundtrack.'. API "
               "/api/train/diffusion/info: families gains a minimax-h3 entry with defaults "
               "rank 16 / lr 1e-4 / resolution 768 / 20 warmup, deploy_base null, and "
               "precision_modes EMPTY (minimax-h3 is not in _DIT_TRAIN_FAMILIES, so /info "
               "advertises no base-precision list for it and recommended_precision is nf4). "
               "CAVEAT to read from the facts rather than assume: family_train_infos drops "
               "a family whose pipeline class the installed diffusers lacks, and H3's is "
               "ModularPipeline, so the row only appears where diffusers exposes it. "
               "RE-RUN AT THE LIVE HEAD (f73ac79e4): the precision_modes clause above is "
               "now OUT OF DATE and is the point of the re-run. The empty list was a real "
               "bug -- family_train_infos read _DIT_TRAIN_FAMILIES for is_dit while the "
               "rest of the PR had moved to _FLOW_TRAIN_FAMILIES -- and it is fixed at this "
               "head, so the pair must now show precision_modes NON-EMPTY for minimax-h3 "
               "and the floating Start control reading 'Start training' and ENABLED after "
               "picking it. A shot that still says 'Not supported on this GPU' means the "
               "AFTER home was built from a stale SHA, not that the fix is absent. "
               "RE-RUN 2026-08-10 (second) WITH OVERRIDDEN REFS AND A SEEDED CLIP FOLDER. "
               "This PR's own merge base can no longer show its effect: head f73ac79e4 "
               "withholds a clip-trained family until a listed dataset reports clips, and "
               "the clip_count field that makes any folder able to report clips is added by "
               "a DIFFERENT open PR, #8287. So the honest pair is BEFORE = 8287 alone "
               "(--base-ref tmp8287) and AFTER = 8287 + 8244 (--head-ref evcomb), with "
               "seed_clips=3 putting the SAME image folder and clip folder in both homes. "
               "Expect: BEFORE 8 options, no MiniMax-H3, target_in_api false; AFTER 9 "
               "options with MiniMax-H3 appended beside LTX-2, target_in_api true, picking "
               "it sets base MiniMaxAI/MiniMax-H3, and the floating Start control reads "
               "'Start training' and is ENABLED (precision_modes non-empty, the fix "
               "described above). The comment MUST say the refs are not 8244's merge base "
               "and why.",
        kwargs={"target": "MiniMax-H3", "family_key": "minimax-h3",
                "pipeline_attr": "ModularPipeline",
                # Taller than 8196's default crop and started past the sidebar: it reaches
                # the foot of the settings column, so the SAME frame carries the family the
                # PR adds and the state of the floating Start control for it. Without the
                # button in shot the pair answers "is it listed" and leaves "can it be
                # started" -- which is where this PR actually fails -- out of frame.
                "clip": {"x": 288, "y": 66, "width": 416, "height": 934},
                # Seeded on BOTH sides. Head f73ac79e4 withholds a clip-trained family
                # until some listed dataset reports clips, so with a stills-only home the
                # AFTER side hides minimax-h3 too and the pair goes identical for a reason
                # that has nothing to do with this PR. The seed is the same folder on both
                # halves, so the family list is still the only thing that differs.
                "seed_clips": 3},
        verified="confirmed by eye at head 70bdc2ceb vs merge base 749437314, two installs, "
                 "both reused on an exact .uidiff_sha match, both on GPU 2 (B200), login "
                 "identity verified per side (BEFORE :8996, AFTER :8997 from the driver's own "
                 "lines). ModularPipeline present on BOTH sides, so the availability filter is "
                 "not what makes the difference (diffusers 0.39.0 BEFORE, 0.40.0.dev0 AFTER -- "
                 "the PR moves the pin; noted because it is a second difference between the "
                 "sides, but it does not gate this row). "
                 "pair_00 menu: 8 options -> 9, MiniMax-H3 appended between Krea 2 and LTX-2, "
                 "exactly the backend order predicted. pair_01 panel: BEFORE stays on the "
                 "FLUX.1-dev default (there is no H3 row to click), AFTER reads MiniMax-H3 with "
                 "chips '31B' + 'QLoRA 72GB+ VRAM', base MiniMaxAI/MiniMax-H3 and the note "
                 "'Video with sound: trains on clips that have a soundtrack.'. So `expect` is "
                 "MATCHED on every clause, including precision_modes [] and "
                 "recommended_precision nf4. "
                 "BUT `expect` stopped one clause short of the thing that decides whether the "
                 "feature ships usable, and the answer is NO. That empty precision_modes is not "
                 "inert: the panel computes familyUntrainable = isDiT && "
                 "precision_modes.length === 0, where isDiT is merely `familyName !== \"sdxl\"`. "
                 "So [] on MiniMax-H3 disables the Start control and labels it 'Not supported on "
                 "this GPU'. Measured on the AFTER build, same Studio process, same B200, "
                 "seconds apart (scripts/h3_8244_start_gate.py): LTX-2 -> 'Start training', "
                 "enabled, precision_modes [nf4,bf16,int8,fp8,mxfp8,auto]; MiniMax-H3 -> 'Not "
                 "supported on this GPU', DISABLED, precision_modes []. Same host, so the "
                 "button's own wording is false. "
                 "ROOT CAUSE, from the net diff: the PR adds _FLOW_TRAIN_FAMILIES = "
                 "_DIT_TRAIN_FAMILIES | {minimax-h3} and switches three call sites to it "
                 "(bf16_unsupported_reason, dit_accelerator_missing_reason, "
                 "training_precision_preflight_error) but NOT the fourth, family_train_infos's "
                 "`is_dit = name in _DIT_TRAIN_FAMILIES`, which is what drives precision_modes. "
                 "The PR touches zero files under studio/frontend/src/features/images/train/. "
                 "THE TRAINER ITSELF IS FINE, which is why this is a listing bug and not a "
                 "feature failure: driving POST /api/train/diffusion/start directly on the same "
                 "build ran a real 20-step H3 LoRA to completion on 3 clips of 1280x720 24-frame "
                 "video WITH AAC stereo audio -- loss 0.415 -> 0.533 (avg 0.683), 0.447 img/s, "
                 "77.76 GB peak, and 332,674,080 B of adapter, 600 tensors over 200 modules at "
                 "rank 16 (lora_A [16,5376] / lora_B [7168,16] on the shared transformer_blocks "
                 "stack, no separate audio/video towers, as the PR's own comment describes). "
                 "GOTCHA: pair_01's two halves differ in BOTH family and button state, so it "
                 "alone cannot support the button claim -- a reader can answer 'different "
                 "families, of course'. The LTX-2 vs MiniMax-H3 shot on ONE build is the "
                 "controlled version and is the image that carries the finding. "
                 "RE-RUN 2026-08-10 at head 256a98a8d vs merge base 587590d6a, both sides "
                 "rebuilt (the stamps for 70bdc2ceb/749437314 no longer matched), login "
                 "identity verified per side, BEFORE :8998 AFTER :8999. The pair is now "
                 "IDENTICAL -- 8 options on both, target_in_api false on both -- and that is a "
                 "RESULT, not a trap. Head commit f73ac79e4 'Withhold a clip-trained family "
                 "from the Train picker until a clip dataset is listable' added "
                 "routes/training.py::_ui_trainable_families, which drops CLIP_TRAINED_FAMILIES "
                 "from /diffusion/info whenever no listed dataset reports clips; "
                 "DiffusionDatasetSummary carries no clip_count field at all yet, so every "
                 "folder answers 0 and minimax-h3 is withheld on every host. ModularPipeline is "
                 "True on both sides, so the availability filter is not the cause. The earlier "
                 "precision_modes finding was FIXED in the meantime (family_train_infos now "
                 "reads _FLOW_TRAIN_FAMILIES for is_dit) and is no longer observable through the "
                 "picker, because the row is not offered at all. "
                 "Trainer proof moved off the picker accordingly: "
                 "scripts/h3_8244_live_train_head.py starts the run through POST "
                 "/diffusion/start (which the gate still accepts by design) on the AFTER build "
                 "and photographs the Train tab mid-run. Completed 20/20, loss 0.415 -> 0.532 "
                 "(avg 0.681), 0.43 img/s, 77.76 GB peak, adapter 332,675,760 B / 600 tensors / "
                 "200 modules at rank 16. Composite: "
                 "outputs/ui_diff_8244/combined/pr8244_h3_trainer_at_head.png (NOT posted as an "
                 "image: its third pane shows the absolute on-disk adapter path). "
                 "MATCHED on the gated re-run, --base-ref tmp8287 (437c1ebe6) --head-ref evcomb "
                 "(631190074), both installs fresh, login identity verified per side, BEFORE "
                 ":9000 AFTER :9003, diffusers 0.40.0.dev0 with ModularPipeline True on both. "
                 "8 -> 9 options, MiniMax-H3 between Krea 2 and LTX-2; target_in_api false -> "
                 "true; the panel picks through to base MiniMaxAI/MiniMax-H3 with chips '31B' + "
                 "'QLoRA 80GB+ VRAM' and the soundtrack note; precision_modes "
                 "[nf4,bf16,int8,auto], recommended auto, and Start reads 'Start training' "
                 "ENABLED on BOTH sides -- so the pair no longer carries the button finding, "
                 "which is now fixed. The seeded dataset row reads 'clip-style - 3 clips' "
                 "identically on both halves, which is what makes the family list the only "
                 "moving part. Posted at "
                 "https://github.com/unslothai/unsloth/pull/8244#issuecomment-5237711835 with "
                 "the ref override stated in the comment itself.",
    ),
    8287: ScenePlan(
        pr=8287, scene="clip_dataset_picker",
        what="Images -> Train, the 'Training images' dataset picker, with an image "
             "folder and a clip folder seeded into the same datasets root",
        expect="BEFORE lists only 'photo-style - 3 images'; the clip folder is invisible "
               "because /diffusion/info admits a folder only on image_count > 0. AFTER "
               "lists BOTH, with 'clip-style - 3 clips' selectable, and picking it leaves "
               "the trigger showing clip-style. The image row must be IDENTICAL on both "
               "halves: if it is not, the panel failed to load and the pair proves nothing.",
        verified="MATCHED on a clean two-install run (base b063387cc, head accdf20fd). Same "
                 "seed on both homes: 3 ffmpeg-encoded MP4s with AAC in clip-style, 3 PNGs in "
                 "photo-style, a .txt beside every file. BEFORE /info returned 1 dataset "
                 "(photo-style, image_count 3, clip_count NULL -- the field does not exist on "
                 "that build) and the menu had 7 options, none of them the clip folder. AFTER "
                 "returned 2 (clip-style image_count 0 / clip_count 3 / caption_count 3, "
                 "photo-style 3/0/3) and the menu had 8, with 'clip-style - 3 clips' at the "
                 "top; dataset_after_pick went from 'photo-style - 3 images' to 'clip-style - "
                 "3 clips'. The control held: the photo-style row is identical on both halves. "
                 "Second pair is worth reading too -- the AFTER panel correctly drops the "
                 "thumbnail strip and the 'Review captions' toggle for a clip-only dataset, "
                 "both of which go through the image thumbnail endpoint.",
    ),
    8267: ScenePlan(
        pr=8267, scene="image_train_base_picker",
        what="Images -> Train, the FLUX.2 Klein family's 'Base model' Select and the "
             "FamilyFacts chips above it",
        # Written from the NET diff (git diff f7ea9fab6 <head>), not the PR body. Two
        # coupled changes: train_base_repos goes from the single distilled
        # black-forest-labs/FLUX.2-klein-4B to the two UNDISTILLED bases base-4B and
        # base-9B, and _BASE_TRAIN_SPECS overlays params 9B / qlora_vram_gb 18 on the 9B
        # one so it stops inheriting the family's 4B / 10 GB floor. FamilyFacts takes
        # baseModel, so the chips are a function of the base pick, not just the family.
        expect="the Base model dropdown under FLUX.2 Klein goes from 2 options "
               "(black-forest-labs/FLUX.2-klein-4B plus 'Custom repo or local path...') "
               "to 3 (FLUX.2-klein-base-4B, FLUX.2-klein-base-9B, Custom). Picking the "
               "9B row, which is impossible on the BEFORE side, moves the chips from "
               "'4B' / 'QLoRA 10GB+ VRAM' to '9B' / 'QLoRA 18GB+ VRAM'. API "
               "/api/train/diffusion/info: the flux.2-klein entry's base_repos goes 1 -> "
               "2, default_base changes from the distilled 4B to base-4B, and base_specs "
               "gains an entry keyed on black-forest-labs/flux.2-klein-base-9b with "
               "params 9B and qlora_vram_gb 18. THE TRAP HERE: the family-level params "
               "and qlora_vram_gb stay 4B / 10 on both sides, so a shot that photographs "
               "the chips WITHOUT picking the 9B base is two identical halves that look "
               "like a passing run. The base pick is the whole point.",
        verified="MATCHED by eye on a clean two-install run, base f7ea9fab6 vs head "
                 "0cd220171. Base menu 2 options -> 3: BEFORE "
                 "['black-forest-labs/FLUX.2-klein-4B', 'Custom repo or local path...'], "
                 "AFTER ['black-forest-labs/FLUX.2-klein-base-4B', "
                 "'black-forest-labs/FLUX.2-klein-base-9B', 'Custom...']. target_in_menu "
                 "False -> True, base_after_pick FLUX.2-klein-4B -> FLUX.2-klein-base-9B, "
                 "chip_texts ['4B'] -> ['9B'], and the panel reads 'QLoRA 10GB+ VRAM' -> "
                 "'QLoRA 18GB+ VRAM'. API: base_repos 1 -> 2, default_base distilled 4B -> "
                 "base-4B, base_specs null -> the 9B base and its unsloth mirror at params "
                 "9B / qlora_vram_gb 18, deploy_bases null -> 4 entries pairing each "
                 "training base to its inference base, vendor and mirror ids alike. "
                 "The predicted trap held exactly: family-level params and qlora_vram_gb "
                 "read 4B / 10 on BOTH sides, so the chip difference exists only after the "
                 "9B row is clicked. "
                 "SCENE GOTCHAS for whoever reuses image_train_base_picker. (1) "
                 "assert_showing waits on a HEADING, and the family name lives in a Select "
                 "trigger, so calling it here would have passed vacuously while the family "
                 "select sat on whatever it defaulted to; the scene asserts the trigger's "
                 "own inner_text instead. (2) the chip regex catches only the params chip "
                 "('4B'/'9B'), not 'QLoRA 18GB+ VRAM', so the VRAM figure comes from the "
                 "API facts and the screenshot rather than chip_texts. (3) the scene prints "
                 "facts truncated to 900 chars, which cut base_after_pick and chip_texts "
                 "off the AFTER line and briefly read like a missed click; the full facts "
                 "are in outputs/ui_diff_8267/meta.json, which is what to check.",
    ),
    7410: ScenePlan(
        pr=7410, scene="local_model_theme",
        what="Studio Model card: the Local Model combobox trigger while its input is "
             "focused (dark), and its open dropdown with a row highlighted (light)",
        expect="two pairs on a seeded scan folder of three safetensors models. "
               "(0) DARK, input focused: BEFORE the pill flips to the translucent "
               "white/12% focus surface InputGroup applies in dark mode, so it turns dark "
               "and stops matching the white Method trigger beside it; AFTER it stays "
               "bg-foreground. Measured as the input-group's computed background-color. "
               "(1) LIGHT, dropdown open on the auto-highlighted first row: BEFORE the "
               "row highlight is the theme's default light-grey --accent with near-black "
               "--accent-foreground, drawn on the dark panel; AFTER --accent is "
               "rgba(255,255,255,0.1) and --accent-foreground white, the same values "
               "DARK_CONTENT already gives the Method dropdown. Measured as the computed "
               "--accent / --accent-foreground on [data-slot=combobox-content] and the "
               "highlighted item's background-color and color.",
        kwargs={},
        verified="confirmed by eye on a clean two-install run, merge base 7f27d8ead vs "
                 "head e3c2f73f3, on macOS 27 / Apple M4 (no GPU path involved). "
                 "pair_00 DARK with the Local Model input focused (:focus-visible asserted, "
                 "not assumed): BEFORE the pill is the translucent white/12% surface, so it "
                 "reads dark against the card while the Method trigger beside it stays "
                 "white; AFTER both pills are the same light surface. Computed "
                 "background-color on [data-slot=input-group] moves "
                 "oklab(0.999994 ... / 0.12) -> rgb(236, 236, 236), which is bg-foreground. "
                 "pair_01 LIGHT with the dropdown open on the auto-highlighted first row: "
                 "BEFORE the highlight is a light-grey bar with near-black text on the dark "
                 "panel; AFTER a white 10% overlay with white text. Computed on "
                 "[data-slot=combobox-content], --accent #ececec -> #ffffff1a and "
                 "--accent-foreground #262626 -> white; the row itself "
                 "rgb(236,236,236)/rgb(38,38,38) -> rgba(255,255,255,0.1)/rgb(255,255,255). "
                 "Both sides list the same six rows (3 seeded + 3 ambient). "
                 "GOTCHAS. (1) THE THEME DOES NOT STAY WHERE localStorage PUTS IT. "
                 "use-personalization-sync loads the stored appearance and calls setTheme "
                 "whenever a record exists, so the dark pass saved dark to the server and "
                 "the light pass loaded it back over the seed: the second shot was of dark "
                 "mode with a 'light' label, and the two halves matched because dark already "
                 "overrides --accent on both sides. The scene now PUTs "
                 "/api/settings/personalization per pass and raises unless "
                 "document.documentElement.className carries the theme it asked for. "
                 "(2) macOS has no setsid, so studio_test_kit.lifecycle.launch_studio cannot "
                 "start Studio at all until it falls back to plain bash (Popen already sets "
                 "start_new_session). (3) HF_HOME and friends do not fully isolate the "
                 "listing: local_inventory scans hf_default_cache_dir() (~/.cache/huggingface"
                 "/hub) whatever the env says, so the seeded rows are pinned to the top of "
                 "the list with a fixed future mtime and the ambient ones are only counted, "
                 "never named. (4) the workspace scripts/ directory is shared with other "
                 "sessions doing the same job, and a fresh copy of the skill overwrites "
                 "registry.py; this run drove a private copy under pr7410ws/scripts with "
                 "UNSLOTH_WORKSPACE pointed at it.",
    ),
    8816: ScenePlan(
        pr=8816, scene="saved_prompt_system_prompt",
        what="Prompt Storage card actions, the Chat Settings System Prompt section and "
             "its editor, on a library of three seeded prompts",
        expect="four differences on the same seeded library (Terse code reviewer, Cited "
               "answers only, Release note writer). (0) the prompt card action row: "
               "'Use' alone -> 'Use' plus a 'System' button. (1) clicking System: the "
               "Chat Settings System Prompt box stays EMPTY on the base build (there is "
               "no such button) and reads 'You are a terse code reviewer. Flag real "
               "defects only.' on the head, with the section header gaining a bookmark "
               "trigger beside the pencil. (2) that bookmark trigger opens a menu listing "
               "all three saved prompts with a tick on the applied one; nothing opens on "
               "the base build because the control does not exist. (3) the Edit System "
               "Prompt dialog footer: 'Reset' alone -> 'Reset' plus 'Save as prompt', and "
               "clicking it puts a fourth entry in /api/prompts/entries named after the "
               "draft's first line, so the count goes 3 -> 4 on the head and stays 3 on "
               "the base. Sampling is untouched on both sides: the PR sets only "
               "params.systemPrompt. TRAP: the card action row is opacity-0 until the "
               "card is hovered, so an unhovered shot photographs an empty row on both "
               "sides and reads as 'this PR changed nothing'.",
        verified="MATCHED on all four pairs, head f58d35887 vs merge base 6f443b5cc, two "
                 "installs on an M4 Mac (24 GB, macOS 27, no GPU used: the whole scene is "
                 "listings and frontend state), login identity verified per side. "
                 "pair_00 card: 'Use' -> 'Use' + 'System' (button title 'Apply as system "
                 "prompt'). pair_01 section: the box stays on its placeholder BEFORE and "
                 "reads 'You are a terse code reviewer. Flag real defects only.' AFTER, "
                 "with a bookmark trigger appearing left of the pencil. pair_02 picker: "
                 "the menu lists all three seeded prompts with a tick on the applied one, "
                 "and Temperature 0.6 / Top P 0.95 / Top K 20 / Min P 0.01 are identical "
                 "on both halves, which is the control for 'sampling untouched'. pair_03 "
                 "editor footer: 'Reset' -> 'Reset' + 'Save as prompt', and clicking it "
                 "takes /api/prompts/entries 3 -> 4 with the new entry named after the "
                 "draft's first line. "
                 "GOTCHAS, three, and the first two both produced a run that looked fine. "
                 "(1) Studio persists params SERVER SIDE, so the system prompt typed by an "
                 "earlier run came back on a fresh browser context and BEFORE reported a "
                 "non-empty prompt it had no way to apply; the scene now clears the box "
                 "first and records system_prompt_at_start. Same class of problem for the "
                 "library itself: the entry saved by the previous AFTER run survived into "
                 "the next one, so the two sides listed 4 and 3 prompts and the control "
                 "broke. The scene now deletes every entry that is not one of its three "
                 "seeds. (2) the composer's Saved prompts submenu is behind 'More', not at "
                 "the top level of the tools menu. (3) the run settings panel is MOUNTED "
                 "OFF CANVAS when closed, at x=1519 with width 0 in a 1500 px viewport, so "
                 "the textarea answers is_visible() True and the element screenshot then "
                 "times out on 'element is not visible'; click 'Open run settings' when it "
                 "is present rather than probing the textarea. "
                 "Two kit changes came out of this run: open_chat takes device_scale_factor "
                 "(the settings panel is 235 CSS px wide, unreadable at 1x once two halves "
                 "sit side by side) and launch_studio skips setsid when the host has none, "
                 "which is every macOS box. Posted at "
                 "https://github.com/unslothai/unsloth/pull/8816#issuecomment-5323520609, "
                 "images on the mahiatlinux/pr-screenshots branch pr8816.",
    ),
    8724: ScenePlan(
        pr=8724, scene="training_chart_axis",
        what="Train -> History -> a past run, the Gradient Norm card's Y axis and its "
             "tooltip on a 25000 spike",
        # From the net diff (git diff 10f34dbf6 20fb4a59c), which is two lines of call
        # site plus a helper: formatMetric and formatAxisMetric stop stripping trailing
        # zeroes when toFixed produced no decimal point. Everything under 1000 keeps a
        # decimal point and is untouched, so the difference only exists on a run whose
        # grad norms clear 1000 AND end in a zero.
        expect="the Gradient Norm Y axis stops reading two-digit nonsense. The seeded run "
               "spans 1000 to 26000, which pads to a domain of [-2000, 29000], so every "
               "tick is a multiple of 500 and BEFORE each one loses its own zeroes: the "
               "axis reads -2, 6, 14, 22, 29 against a curve drawn at 26000, and AFTER it "
               "reads -2000, 6000, 14000, 22000, 29000. The tooltip parked on the step 30 "
               "spike moves the same way: 'Grad Norm 26' -> 'Grad Norm 26000'. Two "
               "controls must NOT move: the step axis (formatStepTick, untouched) and the "
               "API's own 26000, since the PR is frontend only.",
        verified="MATCHED by eye at merge base 10f34dbf6 vs head 20fb4a59c on a clean "
                 "two-install run. Y axis -2, 6, 14, 22, 29 -> -2000, 6000, 14000, 22000, "
                 "29000; tooltip at the step 30 spike 'Grad Norm 26' -> 'Grad Norm 26000'. "
                 "Both controls held: the step axis read 1, 13, 25, 37, 49, 60 on both "
                 "sides and /api/train/runs/{id} returned grad_norm 26000 on both. Posted "
                 "as https://github.com/unslothai/unsloth/pull/8724#issuecomment-5323488309. "
                 "SCENE GOTCHAS for whoever reuses training_chart_axis. (1) THE ONE THAT "
                 "MATTERS: making the SERIES end in zeroes is not enough, the TICKS have to. "
                 "A first series of 840 to 25000 padded to a domain whose ticks were 12941 "
                 "and 20441, which the defect leaves alone, so the pair was identical and "
                 "read as 'this PR changed nothing'. buildYDomain pads by 12 percent of the "
                 "range and recharts lays ticks out from the padded minimum, so the series "
                 "has to be chosen for the domain it produces: 1000 to 26000 gives "
                 "[-2000, 29000] and every tick a multiple of 500. (2) recharts 3.7 renders "
                 "tick labels in their own layer, NOT inside the axis group, so "
                 "`.recharts-yAxis text` matches nothing on a fully drawn chart and the "
                 "scene times out looking like a broken selector; the two axes are told "
                 "apart by orientation=left/bottom. (3) the tooltip label and value run "
                 "together as 'Step 30Grad Norm26', so a `Step 30\\b` regex never matches "
                 "and the hover sweep runs off the end of the chart. (4) reading the "
                 "tooltip through a Playwright locator blocks on its default timeout at "
                 "every step of the sweep, because recharts only attaches the wrapper once "
                 "a point is active; query the DOM directly instead. (5) no GPU, no weights "
                 "and no dataset: the run is seeded straight into <home>/studio.db and read "
                 "back through the normal history route.",
    ),
    8914: ScenePlan(
        pr=8914, scene="external_max_tokens",
        what="Chat run settings -> Sampling -> Max Tokens, on an OpenRouter connection "
             "selected onto minimax/minimax-m3",
        # Written from the NET diff (git diff 6f443b5cc e5a0cefc9), which is four lines in
        # studio/frontend/src/features/chat/provider-capabilities.ts: a `minimax/` arm in
        # _inferProviderFromOpenrouterId, a {providerType: "minimax", prefixes:
        # ["minimax-m3"], cap: 262144} row in EXTERNAL_MAX_OUTPUT_TOKENS_BY_MODEL, and a
        # docs comment. That value reaches the UI through chat-settings-sheet.tsx's
        # `maxTokensMax`, which is the Max Tokens control's `max`.
        expect="the Max Tokens control, driven past its ceiling by typing 999999 into the "
               "field: BEFORE it clamps to 32768 and the slider reports aria-valuemax "
               "32768; AFTER it clamps to 262144 and the slider reports 262144. The "
               "slider thumb moves with it, from hard right (32768 of 32768) to about an "
               "eighth of the track. THREE CONTROLS, read on the same build and required "
               "to be IDENTICAL on the two sides, since a change in any of them is "
               "outside what this PR claims: minimax/minimax-m2 32768 (the tightened "
               "`minimax-m3` prefix must not catch the family's other ids), "
               "deepseek/deepseek-chat 384000 (OpenRouter family inference already worked "
               "here), unknownvendor/some-model 32768 (the conservative fallback "
               "survives). TRAP: DEFAULT_INFERENCE_PARAMS.maxTokens is 8192, under every "
               "cap in the table, so a panel photographed as it opens reads 8192 on both "
               "halves and looks like a clean run of a PR that changed nothing. The "
               "ceiling only shows once the field is pushed past it.",
        verified="MATCHED by eye at head e5a0cefc9 vs merge base 6f443b5cc, two installs, "
                 "login identity verified per side (BEFORE :9601, AFTER :9600). The only "
                 "scene fact that moves is the target: slider_aria_valuemax 32768 -> "
                 "262144 and the field settles on 32768 -> 262144 after 999999 is typed. "
                 "All three controls are byte-identical across the sides: "
                 "minimax/minimax-m2 32768, deepseek/deepseek-chat 384000, "
                 "unknownvendor/some-model 32768. pair_00 (full page) shows the composer "
                 "on 'minimax/minimax-m3 OpenRouter' on both halves; pair_01 (Sampling "
                 "section) shows Temperature through Presence Penalty identical and Max "
                 "Tokens alone moving. Corroborated OFF the UI before the run by importing "
                 "provider-capabilities.ts from both SHAs under node "
                 "--experimental-strip-types and calling getExternalMaxOutputTokens "
                 "directly: same four numbers. "
                 "ONE CLAUSE OF `expect` WAS WRONG and the shot corrects it: the thumb does "
                 "NOT move to an eighth of the track. Typing over the cap clamps the VALUE "
                 "to the ceiling, so valuenow == valuemax and the thumb is hard right on "
                 "both sides; the number beside it is the whole difference. "
                 "MEASUREMENT WORTH REPORTING BESIDE THE PAIR: OpenRouter's own "
                 "/api/v1/models gives minimax/minimax-m3 top_provider.max_completion_tokens "
                 "512000 (context_length 1048576, top_provider.context_length 524288) as of "
                 "2026-08-18, so the PR's 262144 is conservative by 2x against the source it "
                 "cites. The same listing documents 131072 for minimax/minimax-m2 and m2.1 "
                 "and m2.7, 196608 for m2.5, 1000192 for minimax-01 and 40000 for m1, all of "
                 "which the tightened `minimax-m3` prefix leaves on the 32768 fallback. That "
                 "is the PR's stated scope, not a defect, but it is what the m2 control "
                 "photographs. "
                 "SCENE GOTCHAS, all four of which produced a clean-looking failure. "
                 "(1) CONNECTIONS ARE NO LONGER LOCALSTORAGE. "
                 "syncExternalProvidersFromBackend REPLACES the store with /api/providers/ "
                 "on every boot, so studio_test_kit's ProviderSeed path leaves the composer "
                 "reading 'minimax/minimax-m3 No longer offered' -- the model id is still "
                 "shown, so an assertion on the id alone passes on a dead connection. The "
                 "scene creates the connection through POST /api/providers/ and asserts the "
                 "provider NAME in the pill too. (2) The run settings panel is CLOSED on a "
                 "fresh profile and animates its width open, and every control inside reads "
                 "`visible` the whole time, including at 0 px wide with its contents "
                 "overhanging the viewport: the aria values are correct, so the numbers "
                 "look right while the screenshot is of nothing and clicks fail as 'outside "
                 "of the viewport'. Gate on the measured width of .run-settings-scroll. "
                 "(3) Walking up from the Max Tokens input by class lands on a 16 px "
                 "scrollbar-gutter div that still reports the section's whole inner_text, so "
                 "the text assertions pass and the shot is a blank sliver; anchor on the "
                 "Sampling header button and take its parent. (4) A parallel run on this box "
                 "killed this one's Studio with `pkill -f \"unsloth studio -p 89\"`; "
                 "pick_free_ports now honours UIDIFF_PORT_START / UIDIFF_PORT_STOP. Posted at https://github.com/unslothai/unsloth/pull/8914#issuecomment-5323535376, images on the mahiatlinux/unsloth branch pr8914-ui-evidence.",
    ),
    8979: ScenePlan(
        pr=8979, scene="settings_key_cycle_boot",
        what="Studio's first paint after login, with the app-sidebar import order the PR "
             "body names as the reproduction applied identically to both sides",
        # Written from the NET diff (git diff 27326c4d8 5b2b81e19). The PR moves
        # SIDEBAR_ORGANIZATION_STORAGE_KEY out of sidebar-organization-store.ts, which
        # imports zustand and sits in an import cycle through the @/features/chat barrel,
        # into sidebar-organization-keys.ts, which imports nothing. general-tab.tsx reads
        # that key in a top-level const, so entering the cycle from the settings side left
        # it in its temporal dead zone.
        expect="a WHITE SCREEN on the BEFORE half and the normal Studio chat shell on the "
               "AFTER half. BEFORE the page reports an empty #root and a pageerror "
               "reading \"Cannot access 'SIDEBAR_ORGANIZATION_STORAGE_KEY' before "
               "initialization\"; AFTER #root has the sidebar, the composer and the rest "
               "of the app, with no such error. "
               "REFS ARE OVERRIDDEN and the comment must say so: photographed at the PR's "
               "own merge base and head the two halves are IDENTICAL, because "
               "app-sidebar.tsx imports the theme toggler about 115 lines above its own "
               "chat import and so happens to evaluate the store first. Both sides "
               "therefore carry the same one-line reordering (the theme-toggler import "
               "moved below the chat barrel import), which is the reproduction the PR "
               "body describes. BEFORE = merge base 27326c4d8 + that edit, AFTER = head "
               "5b2b81e19 + the same edit. The edit is byte-identical on the two sides, "
               "so the only thing the pair isolates is the key's module.",
        verified="CONTRADICTS expect. Both halves render the full chat shell: BEFORE "
                 "root_html_len 95133 / AFTER 95119, composer present on both, "
                 "page_error_count 0 on both, tdz_error empty on both. The root_html_len "
                 "delta is the randomised greeting ('What's on your mind today?' vs 'Good "
                 "to see you'), not the PR. The white screen does not reproduce at the "
                 "merge base under the reordering the PR body names, in the production "
                 "install or in the vite dev server, and the Settings General tab opens "
                 "normally on the BEFORE build. "
                 "WHY: the TDZ needs general-tab.tsx to read the key through the "
                 "@/features/chat barrel while that barrel is mid-evaluation. main reads "
                 "it from the deep path @/features/chat/stores/sidebar-organization-store, "
                 "and that store is a leaf (zustand only), so importing it directly always "
                 "completes its evaluation. Measured both ways on the merge base with a "
                 "vite entry importing the chat barrel first: with the barrel import "
                 "patched in, root is empty and the page throws \"Cannot access "
                 "'SIDEBAR_ORGANIZATION_STORAGE_KEY' before initialization\"; with the "
                 "direct import as shipped, it renders. The barrel form was the state "
                 "#8932 introduced and #8956 already replaced with the direct path, which "
                 "is in this PR's merge base. 8979 moves the key to a leaf module on top "
                 "of that, so it is defence in depth plus a static test, not a fix for a "
                 "reachable white screen.",
    ),
    9123: ScenePlan(
        pr=9123, scene="composer_stop_queue",
        what="chat composer action row, mid-stream, with text typed into the composer",
        expect="BEFORE shows the round Queue arrow alone (Stop generating is gone while "
               "text sits in the composer); AFTER shows the square Stop generating button "
               "AND the Queue arrow side by side. Facts: running_actions_typed_composer "
               "['Queue message'] -> ['Stop generating', 'Queue message'], stop_visible "
               "false -> true, queue_visible true on both.",
        verified="confirmed by eye at head 99092761a vs merge base a4fa45121 on two "
                 "isolated installs. Held identical on both sides: the same custom "
                 "OpenAI-compatible provider streaming on a 400 ms clock, the same reply "
                 "paused at 10 painted tokens, the same text typed into the composer. "
                 "Empty composer while running reads ['Dictate', 'Stop generating'] on "
                 "BOTH sides, so the PR touches only the typed case. With the text in: "
                 "BEFORE ['Dictate', 'Queue message'] (stop_visible false) -> AFTER "
                 "['Dictate', 'Stop generating', 'Queue message'] (stop_visible true). "
                 "SCENE NOTES for whoever reuses composer_stop_queue. (1) the model is "
                 "selected by seeding unsloth_chat_last_external_checkpoint with "
                 "external::<providerId>::<modelId> rather than by driving the picker, "
                 "which is a multi-tab surface whose rows move between builds. (2) the "
                 "provider must be created through POST /api/providers/; the frontend "
                 "syncs its list down from the server and prunes anything planted in "
                 "localStorage alone. (3) the running state is asserted on the absence of "
                 "the Send button and on the reply's token count still growing between two "
                 "reads, since a stream that finished early puts both sides back on Send "
                 "and photographs as no change. (4) the thread shot is clipped past the "
                 "sidebar: its Recents list carries whatever earlier runs left in that "
                 "home and would read as a difference between the sides.",
    ),
    8833: ScenePlan(
        pr=8833, scene="video_model_picker_h3_rows",
        what="video model picker while the browser is a Mac and the Studio it drives "
             "resolves an accelerated backend (cuda, rocm or xpu)",
        expect="8 rows -> 9: the MiniMax H3 pipeline row is offered for the first time, "
               "and both H3 rows gain their speed qualifier, 'MiniMax H3 (Fast FP8)' and "
               "'MiniMax-H3-GGUF (Slow)'. A Mac reporting its OWN backend (mlx or cpu) "
               "must stay at 8 rows with a bare 'MiniMax H3 (GGUF)', which is 8822's "
               "behaviour and the thing this PR must not undo.",
        verified="NOT SHOOTABLE on this host, and no pair was posted. The difference needs "
                 "deviceType 'mac' together with a backend of cuda, rocm or xpu, so it "
                 "requires a Mac browser pointed at a REMOTE accelerated Studio. This box "
                 "is an M4 MacBook Air: no nvidia-smi, no rocm-smi, and install.sh builds "
                 "an MLX Studio, so both sides classify gguf-only and the pair would be "
                 "identical for a reason that has nothing to do with the PR. Faking "
                 "device_backend would have produced a screenshot of hardware that does "
                 "not exist, so the classification was MEASURED instead, running "
                 "classifyHost and catalogToModelOptions(VIDEO_CATALOG) from both SHAs "
                 "under node --experimental-strip-types (both files import only types, so "
                 "no node_modules needed). merge base afa9d8109 vs head 6a58cdf7f: "
                 "mac+cuda, mac+rocm and mac+xpu all go gguf-only -> accelerated, 8 rows "
                 "-> 9, h3_pipeline_offered false -> true, and the two H3 labels gain "
                 "'(Fast FP8)' and '(Slow)'. mac+mlx and mac+cpu are gguf-only/8 rows on "
                 "both sides, and linux+cuda is accelerated/9 rows on both sides.",
    ),
    8595: ScenePlan(
        pr=8595, scene="custom_provider_max_tokens",
        what="Chat -> run settings -> Sampling, the Max Tokens ceiling for a custom "
             "OpenAI-compatible connection serving deepseek-v4-flash",
        # From the net diff (git diff 51fac012b 3bd31d681): one condition in
        # getExternalMaxOutputTokens. Rows of EXTERNAL_MAX_OUTPUT_TOKENS_BY_MODEL stop
        # being gated on providerType when the connection resolved to the legacy
        # "custom" type, so the model id alone decides the cap.
        expect="the Max Tokens slider ceiling goes 32768 -> 384000 for deepseek-v4-flash "
               "behind a Custom connection. Typing 999999 into the field clamps to that "
               "ceiling, so the number on screen reads 32768 BEFORE and 384000 AFTER, "
               "with the slider thumb pinned right on both. THE TRAP: the connection must "
               "resolve to providerType 'custom' in the SPA store. Seeded as 'openai' it "
               "is a first-party row, keeps the gate on both sides, and photographs as two "
               "identical 32768s that read as 'this PR changed nothing'. The scene creates "
               "it through POST /api/providers and asserts the type the SPA's own sync "
               "resolved.",
        verified="MATCHED by eye on a clean two-install run, base 51fac012b vs head "
                 "3bd31d681. max_tokens_ceiling 32768 -> 384000, the value left after "
                 "typing 999999 32768 -> 384000, slider aria-valuenow the same, and "
                 "ui_provider_type 'custom' with the identical model chip "
                 "'deepseek-v4-flash / DeepSeek Gateway' on BOTH sides, so the only thing "
                 "that moved is the cap. SCENE GOTCHAS for whoever reuses "
                 "custom_provider_max_tokens. (1) the connection MUST be created through "
                 "POST /api/providers and left to the SPA bootstrap; seeding "
                 "unsloth_chat_external_providers writes the type this file chose, and an "
                 "'openai' seed is a first-party row that caps both sides at 32768. The "
                 "scene reads providerType back out of localStorage and refuses to shoot "
                 "anything else. (2) the Max Tokens field is type=text with no max "
                 "attribute, so the ceiling comes off the Radix slider's aria-valuemax "
                 "beside it, not the input. (3) connected models are plain buttons "
                 "wrapping the name, not role=option, so a get_by_role('option') locator "
                 "finds nothing. (4) the panel alone never says which model it describes; "
                 "the scene stacks the header chip crop above it, since the chip sits "
                 "1000px away at the other end of the page. (5) macOS has no setsid: "
                 "studio_test_kit.lifecycle now falls back to a bare bash -c, and "
                 "_find_unsloth_bin globs .venv_t5_* rather than listing pinned names.",
    ),
}


def plan_for(pr: int) -> ScenePlan:
    if pr not in REGISTRY:
        raise KeyError(
            f"no scene registered for PR {pr}. Add a ScenePlan to REGISTRY with an "
            f"`expect` describing the difference the screenshot must show."
        )
    return REGISTRY[pr]
