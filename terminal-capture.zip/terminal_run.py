import json, os, pathlib, subprocess, sys, time
root=pathlib.Path('/task')
side=sys.argv[1]
connection=json.loads((root/f'connection-{side}.json').read_text())
model='Qwen3-0.6B-Q4_K_M'
prompt='Summarize these notes in one sentence.\n'+'\n'.join(f'Note {i:04d}: the quick brown fox jumps over the lazy dog beside the quiet riverbank at dawn.' for i in range(700))
config_home=root/f'codex-{side}'; config_home.mkdir(exist_ok=True)
(config_home/'config.toml').write_text(f'''model = "{model}"
model_provider = "studio"
model_context_window = 100000
[model_providers.studio]
name = "Studio"
base_url = "http://127.0.0.1:{connection['port']}/v1"
wire_api = "responses"
env_key = "STUDIO_API_KEY"
''')
label='BEFORE | base 03af220ac002' if side=='base' else 'AFTER | head 2a2cac7499d4'
print(f'PR #10938 | {label}',flush=True)
print('$ codex exec --skip-git-repo-check --sandbox read-only - < overflow-prompt.txt',flush=True)
start=time.monotonic()
result=subprocess.run(['/task/bin/codex','exec','--skip-git-repo-check','--sandbox','read-only','--color','never','-'],input=prompt,text=True,cwd='/task/tmp',env=dict(os.environ,CODEX_HOME=str(config_home),STUDIO_API_KEY=connection['key']),timeout=180)
print(f'\nPR #10938 | {label}',flush=True)
print('Codex 0.154.0 | Qwen3-0.6B Q4_K_M | context 4096 | NVIDIA RTX 5060 Ti',flush=True)
print(f'Process exit: {result.returncode} | elapsed: {time.monotonic()-start:.2f}s',flush=True)
(root/f'done-{side}.json').write_text(json.dumps({'side':side,'exit':result.returncode}))
