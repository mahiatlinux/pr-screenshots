import asyncio
import json
import pathlib
import secrets
import sys
root = pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'evidence-scripts'))
from pr_ui_scenes._common import studio_session
from pr_ui_scenes import top_p_off_gateway as scene
from studio_test_kit.auth import seed_init_script
from studio_test_kit.ui import open_chat
from playwright.async_api import expect
scene.ANSWER='Hello from the strict test gateway.'
scene.BEDROCK_ERROR='`temperature` and `top_p` cannot both be specified for this model.'
async def main():
    session=studio_session('http://127.0.0.1:19348',root/'scratch/roundtrip4-head',secrets.token_urlsafe(24))
    server,port,received=scene._start_standin()
    facts=[]
    try:
        provider=scene._create_provider(session,port)
        model=f'external::{provider}::{scene.PROVIDER_MODEL}'
        thread='pr10934-toggle-regression'
        scene._seed_thread(session,thread,model)
        auth=seed_init_script(session,[])
        async with open_chat(session.base_url,init_scripts=[auth,scene._connections_init_script(model,provider)]) as sp:
            page=sp.page
            await page.goto(f'{session.base_url}/chat?thread={thread}')
            composer=page.locator('form:has(textarea) textarea').first
            await composer.wait_for(state='visible')
            await page.wait_for_timeout(2000)
            opener=page.get_by_role('button',name='Open run settings',exact=True)
            if await opener.count(): await opener.click()
            control=page.locator('input[aria-label="Top P"]').first
            for value,status,label in [('0.9',400,'explicit'),('1',200,'off-recovery')]:
                if status == 400:
                    await control.fill(value)
                    await control.press('Enter')
                    await control.blur()
                else:
                    row = page.locator('div.space-y-3\\.5').filter(has=control).first
                    await row.locator('[role=slider]').first.focus()
                    await page.keyboard.press('End')
                await page.wait_for_timeout(500)
                display=await control.input_value()
                before=len(received)
                if status == 400:
                    await composer.fill('Say hello in one short sentence.')
                    await page.get_by_role('button',name='Send message',exact=True).click()
                else:
                    await page.get_by_role('button',name='Retry',exact=True).click()
                for _ in range(120):
                    if len(received)>before: break
                    await page.wait_for_timeout(250)
                last=received[-1]
                assert last['status']==status,last
                if status==400:
                    assert last['body']['top_p']==0.9
                    await expect(page.locator('[role="alert"]').last).to_contain_text('cannot both be specified')
                else:
                    assert 'top_p' not in last['body']
                    assert display=='Off',display
                    await expect(page.locator('.aui-assistant-message-content').last).to_contain_text(scene.ANSWER)
                await page.wait_for_timeout(500)
                await sp.screenshot(root/f'artifacts/ui/roundtrip-{label}.png',full_page=False)
                facts.append({'display':display,'status':status,'top_p_present':'top_p' in last['body'],'top_p':last['body'].get('top_p')})
                (root/'artifacts/roundtrip-facts.json').write_text(json.dumps(facts,indent=2))
            await page.reload()
            await control.wait_for(state='visible')
            await expect(control).to_have_value('Off', timeout=15000)
            facts.append({'reload_preserved_off':True})
        (root/'artifacts/roundtrip-facts.json').write_text(json.dumps(facts,indent=2))
        print(json.dumps(facts))
    finally:
        server.shutdown()
        server.server_close()
asyncio.run(main())
