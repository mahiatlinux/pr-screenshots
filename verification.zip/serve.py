import os, sys, pathlib, time, json
side = sys.argv[1]
root = pathlib.Path('/task')
os.environ.update(UNSLOTH_STUDIO_HOME=str(root/f'home-{side}'), LLAMA_SERVER_PATH='/task/llama/llama-server', UNSLOTH_STUDIO_DISABLE_DEVICE_PROBE='1', UNSLOTH_ALLOW_CPU='1')
sys.path.insert(0, str(root/side))
from unsloth_cli.commands.studio import _load_run_module, _create_api_key_inprocess, _load_model_via_http
run_mod = _load_run_module()
app = run_mod.run_server(host='127.0.0.1', port=0, silent=True, api_only=True, llama_parallel_slots=1, cloudflare=False, secure=False, emit_tauri_port=False, abort_if_own_studio=False)
port = app.state.server_port
key = _create_api_key_inprocess('pr10938-disposable')
result = _load_model_via_http(port=port, api_key=key, model='/task/downloads/Qwen3-0.6B-Q4_K_M.gguf', gguf_variant=None, max_seq_length=4096, load_in_4bit=True, gpu_memory_mode='manual', tensor_parallel=False, speculative_type=None, spec_draft_n_max=None, llama_extra_args=['--n-gpu-layers','99','--seed','3407'], request_host='127.0.0.1')
(root/f'connection-{side}.json').write_text(json.dumps({'port':port,'key':key}))
(root/'artifacts'/f'loaded-{side}.json').write_text(json.dumps(result,indent=2))
print(f'READY {side} port={port}',flush=True)
try:
    while True:
        time.sleep(1)
finally:
    run_mod._graceful_shutdown(run_mod._server)
