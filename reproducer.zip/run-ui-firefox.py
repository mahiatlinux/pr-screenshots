import asyncio
import json
import os
import pathlib
import secrets
import sys
root = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(root/'evidence-scripts'))
os.environ['UNSLOTH_WORKSPACE'] = str(root)
from pr_ui_scenes._common import studio_session
from pr_ui_scenes.registry import ScenePlan
from pr_ui_scenes import top_p_off_gateway as scene
from pr_ui_diff import _facts_diff, _same_bytes
from PIL import Image, ImageDraw
plan = ScenePlan(pr=10934, scene='top_p_off_gateway', what='Chat with Top P at Off', expect='Base shows temperature/top_p conflict with top_p=1 in the gateway request; head omits top_p and displays the gateway reply.')
(root/'artifacts/ui-expect.json').write_text(json.dumps(plan.__dict__,indent=2))
scene.ANSWER = 'Hello from the strict test gateway.'
scene.BEDROCK_ERROR = '`temperature` and `top_p` cannot both be specified for this model.'
async def main():
    all_facts = {}
    shots = []
    for side, label, port in [('base','BEFORE',19343), ('head','AFTER',19344)]:
        session = studio_session(f'http://127.0.0.1:{port}',root/f'scratch/firefox-{side}',secrets.token_urlsafe(24))
        result, facts = await scene.drive(session,root/'artifacts/firefox-ui',label)
        all_facts[side] = facts
        shots.extend(result)
        (root/f'artifacts/firefox-{side}-facts.json').write_text(json.dumps(facts,indent=2))
        print(side, json.dumps(facts),flush=True)
    assert all_facts['base']['error_visible']
    assert all_facts['base']['top_p_sent'] == 1
    assert all_facts['head']['assistant_answered']
    assert not all_facts['head']['top_p_in_body']
    assert _facts_diff(all_facts['base'],all_facts['head'])
    assert not _same_bytes(*shots)
    images = [Image.open(p).convert('RGB') for p in shots]
    canvas = Image.new('RGB',(2880,960),'white')
    draw = ImageDraw.Draw(canvas)
    for idx,(img,label) in enumerate(zip(images,['BEFORE: base 5c04ec1930','AFTER: head b78f181210'])):
        canvas.paste(img,(1440*idx,60))
        draw.text((1440*idx+24,15),label,fill='black',font_size=28)
    canvas.save(root/'artifacts/firefox-ui/pr10934-before-after.png')
asyncio.run(main())
